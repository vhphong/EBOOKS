export const environment = {
  production: true,
  WORDPRESS_REST_URL: 'https://demo8034777.mockable.io/'
};
