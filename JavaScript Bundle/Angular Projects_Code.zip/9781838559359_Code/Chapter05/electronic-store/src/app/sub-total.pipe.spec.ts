import { SubTotalPipe } from './sub-total.pipe';

describe('SubTotalPipe', () => {
  it('create an instance', () => {
    const pipe = new SubTotalPipe();
    expect(pipe).toBeTruthy();
  });
});
