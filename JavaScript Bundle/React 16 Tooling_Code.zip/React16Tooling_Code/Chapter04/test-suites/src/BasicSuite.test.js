describe('BasicSuite', () => {
  it('passes the first test', () => {
    // Assertions...
  });

  it('passes the second test', () => {
    // Assertions...
  });
});
