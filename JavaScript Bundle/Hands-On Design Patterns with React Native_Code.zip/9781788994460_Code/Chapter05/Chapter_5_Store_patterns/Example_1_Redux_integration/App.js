import App from './src/Counter';

export default App;
