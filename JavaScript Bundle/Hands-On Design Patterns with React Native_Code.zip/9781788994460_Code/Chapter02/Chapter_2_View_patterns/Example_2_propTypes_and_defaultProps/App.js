import makeExpandable from './src/makeExpandable';
import HelloBox from './src/HelloBox';

export default makeExpandable(HelloBox);
