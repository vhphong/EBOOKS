export const API = Object.freeze({
  TODO: 'api/todo/list'
});
