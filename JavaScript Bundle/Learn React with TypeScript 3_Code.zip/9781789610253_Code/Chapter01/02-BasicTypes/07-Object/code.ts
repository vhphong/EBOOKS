const customer = {
  name: "Lamps Ltd",
  turnover: 2000134,
  active: true
};

customer.turnover = 500000;

customer.profit = 10000;
