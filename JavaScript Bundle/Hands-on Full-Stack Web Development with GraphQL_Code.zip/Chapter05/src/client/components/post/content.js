import React from 'react';

export default ({post}) => 
    <p className="content">
        {post.text}
    </p>