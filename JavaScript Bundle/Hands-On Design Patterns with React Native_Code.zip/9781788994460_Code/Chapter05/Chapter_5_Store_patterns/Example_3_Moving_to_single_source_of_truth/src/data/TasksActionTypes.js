const ActionTypes = {
    ADD_TASK: 'ADD_TASK',
    TASK_FORM_CHANGE: 'TASK_FORM_CHANGE'
};

export default ActionTypes;
