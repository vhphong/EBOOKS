// Dependencies
import React from 'react';

// Components
import Home from './Home';

const App = props => (
  <div>
    <Home />
  </div>
);

export default App;
