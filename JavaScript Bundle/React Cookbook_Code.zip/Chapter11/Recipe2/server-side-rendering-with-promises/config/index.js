export default {
  baseUrl: 'http://localhost:3000'
};
