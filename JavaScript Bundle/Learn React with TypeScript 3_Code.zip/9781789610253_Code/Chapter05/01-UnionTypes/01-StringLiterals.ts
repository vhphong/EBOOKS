type Control = "Textbox";

let notes: Control;
notes = "Textbox";
notes = "DropDown";
notes = null;
notes = undefined;
