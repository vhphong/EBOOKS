import React from 'react';
import ReactDOM from 'react-dom';
import MyComponent from './MyComponent';

const root = document.getElementById('root');

ReactDOM.render(
  <MyComponent />,
  root,
);
