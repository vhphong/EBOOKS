function logScores(...scores) {
  console.log(scores);
}

logScores(50, 85, 75); // [50, 85, 75]
