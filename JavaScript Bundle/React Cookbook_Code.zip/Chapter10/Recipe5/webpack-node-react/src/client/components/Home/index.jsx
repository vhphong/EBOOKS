import React from 'react';
import styles from './Home.scss';

const Home = () => (
  <h1 className={styles.Home}>React Running on Node</h1>
);

export default Home;
