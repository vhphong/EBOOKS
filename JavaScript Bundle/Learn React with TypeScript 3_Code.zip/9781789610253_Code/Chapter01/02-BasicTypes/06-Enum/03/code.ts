enum OrderStatus {
  Paid = 1,
  Shipped = 2,
  Completed = 3,
  Cancelled = 0
}

let status = OrderStatus.Shipped;
console.log(status);
