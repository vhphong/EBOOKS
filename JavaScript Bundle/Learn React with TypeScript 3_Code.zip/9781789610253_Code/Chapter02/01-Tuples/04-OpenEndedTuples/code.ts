type Scores = [string, ...number[]];

// Okay
const billyScores: Scores = ["Billy", 60, 70, 75];

// Still okay!
const sallyScores: Scores = ["Sally", 60, 70, 75, 70];
