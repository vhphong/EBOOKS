import App from './src/App';

export default App;
