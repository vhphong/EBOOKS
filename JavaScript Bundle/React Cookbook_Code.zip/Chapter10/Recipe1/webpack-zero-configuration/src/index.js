import { numbers } from './numbers';

numbers.forEach(number => console.log(number));
