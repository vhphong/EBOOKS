import taskReducer from './taskReducer';

export default { tasks: taskReducer };
