function logText(text: string): void {
  console.log(text);
}
