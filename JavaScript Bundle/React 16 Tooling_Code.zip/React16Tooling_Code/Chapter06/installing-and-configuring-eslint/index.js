export const myFunc = () => 'myFunc';
