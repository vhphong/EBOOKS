import React from 'react';
import LikeCounter from './src/LikeCounter';

export default () => <LikeCounter />;
