const ActionTypes = {
    ADD_TASK: 'ADD_TASK'
};

export default ActionTypes;
