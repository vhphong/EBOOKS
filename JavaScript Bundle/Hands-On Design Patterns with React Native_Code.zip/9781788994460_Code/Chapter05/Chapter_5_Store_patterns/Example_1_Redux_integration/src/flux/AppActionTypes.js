const ActionTypes = {
    INC_COUNTER: 'INC_COUNTER',
    DEC_COUNTER: 'DEC_COUNTER'
};

export default ActionTypes;
