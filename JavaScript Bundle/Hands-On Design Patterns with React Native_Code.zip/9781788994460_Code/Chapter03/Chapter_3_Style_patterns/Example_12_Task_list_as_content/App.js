import React from 'react';
import App from './src/App';

// Beware, this app is not anyhow production ready with styles.
// We made a good amount of work but there are still issues.
// Your homework is to find them.
// One problem that is easy to find involves rotation. Good Luck.

export default () => <App />;
