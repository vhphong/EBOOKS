abstract class Product {
  name: string;
  unitPrice: number;
}

const bread = new Product();
