# Install

```sh
npm install
```

# Run

```sh
node app
```
