type Control = "Textbox" | "DropDown" | "DatePicker" | "NumberSlider";

let notes: Control;
notes = "Textbox";
notes = "DropDown";
notes = "DatePicker";
notes = "NumberSlider";
