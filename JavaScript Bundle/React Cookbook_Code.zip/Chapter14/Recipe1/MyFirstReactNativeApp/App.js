// Dependencies
import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View } from 'react-native';

// Components
import Home from './components/Home';

class App extends Component {
  render() {
    return (
      <Home />
    );
  }
}

export default App;
