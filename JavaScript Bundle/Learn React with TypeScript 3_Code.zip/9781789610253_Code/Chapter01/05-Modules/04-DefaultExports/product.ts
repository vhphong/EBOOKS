export default interface {
  name: string;
  unitPrice: number;
}
