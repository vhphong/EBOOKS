enum OrderStatus {
  Paid,
  Shipped,
  Completed,
  Cancelled
}

let status = OrderStatus.Shipped;
