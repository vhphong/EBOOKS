This project contains the completed code for the React shop built in the first section of chapter 7.
To restore this:

- Copy the contents of the `01-CreatingAFormWithControlledComponents` folder into a folder of your choice
- Open the folder in Visual Studio Code
- Run the following command in the Terminal:

```
npm install
```

The following Terminal command will then run the project in the web development server:

```
npm start
```
