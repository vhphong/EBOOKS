Chapters 2,3,4,5,6 contains code files.
Chapters 1,8,9 does not contain code files as they are theoratical chapters and have non executable small code lines.