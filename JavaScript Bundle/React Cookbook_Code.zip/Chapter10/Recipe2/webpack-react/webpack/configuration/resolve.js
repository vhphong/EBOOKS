export default {
  extensions: ['.js', '.jsx']
}
