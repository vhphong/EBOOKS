import React from 'react';
import LoginForm from './src/LoginForm';
import {TextInput, Text, View, Button} from 'react-native'

export default () => <LoginForm />

