export default req => ({
  device: {
    isMobile: req.isMobile
  }
});
