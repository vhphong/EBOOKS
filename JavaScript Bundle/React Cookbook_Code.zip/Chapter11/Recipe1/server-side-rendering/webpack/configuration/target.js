export default type => type === 'server' ? 'node' : 'web';
