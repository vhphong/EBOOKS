interface Product {
  name: string;
  unitPrice: number;
}

const table: Product = {
  name: "Table",
  unitPrice: 500
};

const chair: Product = {
  productName: "Table",
  price: 70
};
