import store from './AppStore';

export default store;
