export interface Product {
  name: string;
  unitPrice: number;
}
