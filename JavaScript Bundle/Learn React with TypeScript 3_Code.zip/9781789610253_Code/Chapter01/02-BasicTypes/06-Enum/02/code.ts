enum OrderStatus {
  Paid = 1,
  Shipped,
  Completed,
  Cancelled
}

let status = OrderStatus.Shipped;
console.log(status);
