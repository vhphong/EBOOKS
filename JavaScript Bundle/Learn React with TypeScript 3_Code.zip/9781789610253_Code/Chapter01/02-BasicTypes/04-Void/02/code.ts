function logText(text: string) {
  console.log(text);
}
