This project contains the completed code for the confirmation component built in chapter 3.
To restore this:

- Copy the contents of the `02-ConfirmComponent` folder into a folder of your choice
- Open the folder in Visual Studio Code
- Run the following command in the Terminal:

```
npm install
```

The following Terminal command will then run the project in the web development server:

```
npm start
```
