var threeSquared: number = 3 ** 2;
console.log(threeSquared);
