import React from 'react';
import TextInputExample from './src/TextInputExample';

export default () => <TextInputExample />;
