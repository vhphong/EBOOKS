import React from 'react';

const MyChild = ({ children }) => <p>{children}</p>;

export default MyChild;
