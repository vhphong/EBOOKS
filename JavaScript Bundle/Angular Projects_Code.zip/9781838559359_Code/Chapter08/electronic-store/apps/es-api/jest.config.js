module.exports = {
  name: 'es-api',
  preset: '../../jest.config.js',
  coverageDirectory: '../../coverage/apps/es-api'
};
