import React from 'react';

const Child = () => (
  <p>The Child</p>
);

export default Child;
