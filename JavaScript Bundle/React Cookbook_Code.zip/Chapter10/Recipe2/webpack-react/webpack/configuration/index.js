// Configuration
import module from './module';
import plugins from './plugins';
import resolve from './resolve';

export {
  module,
  plugins,
  resolve
};
