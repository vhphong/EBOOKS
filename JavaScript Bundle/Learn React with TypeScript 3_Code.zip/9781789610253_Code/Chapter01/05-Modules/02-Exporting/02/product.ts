interface Product {
  name: string;
  unitPrice: number;
}

export { Product };
