function foreverTask(taskName: string) {
  while (true) {
    console.log(`Doing ${taskName} over and over again ...`);
  }
}
