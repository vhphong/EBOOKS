import App from './src/screens/TaskListScreen';

export default App;
