// Actions
export const FETCH_TODO = {
  request: () => 'FETCH_TODO_REQUEST',
  success: () => 'FETCH_TODO_SUCCESS'
};
