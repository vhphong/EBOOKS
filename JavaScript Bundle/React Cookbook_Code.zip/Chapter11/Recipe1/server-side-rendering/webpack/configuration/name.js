export default type => type;
