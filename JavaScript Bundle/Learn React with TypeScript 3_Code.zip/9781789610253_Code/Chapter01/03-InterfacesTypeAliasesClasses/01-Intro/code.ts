let customer: object;
customer = {
  name: "Lamps Ltd",
  turnover: 2000134,
  active: true
};
customer.turnover = 2000200;
