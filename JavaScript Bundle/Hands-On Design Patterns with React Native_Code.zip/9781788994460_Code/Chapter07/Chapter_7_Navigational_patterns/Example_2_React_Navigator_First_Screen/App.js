import App from './src/screens/index';

export default App;
