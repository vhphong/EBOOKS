export default function deviceReducer(state = {}) {
  return state;
}
