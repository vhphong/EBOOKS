'use strict';

/**
* Change into specs folder so that file loading works.
*/
process.chdir('./specs');

require('./helpers/chai.js');

// Tests go here.
