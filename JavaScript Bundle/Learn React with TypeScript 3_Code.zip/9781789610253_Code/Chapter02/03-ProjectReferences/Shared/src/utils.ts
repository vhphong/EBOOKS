export function randomString() {
  return Math.floor((2 + Math.random()) * 0x10000).toString(16);
}
